package com.pro.shardingExmaple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShardingExmapleApplicationTests {

	@Test
	void contextLoads() {
	}

}
